<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Link Shortener</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
  <div class="container mx-auto mt-5 px-4">
    <h1 class="text-3xl">
      Link Shortener of smasa.id
    </h1>
    <?php if(session()->has('success')): ?>
      <p class="text-green-500"><?php echo e(session()->get('success')); ?></p>
    <?php endif; ?>
    <form class="w-full max-w-lg mt-5" action="/" method="post" role="form" autocomplete="off">
      <?php echo csrf_field(); ?>
      <div class="flex flex-wrap -mx-3 mb-6">
        <div class="w-full px-3">
          <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="name">
            Link name
          </label>
          <input class="appearance-none block w-full bg-gray-200 text-gray-700 border <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="name" name="name" type="text" placeholder="Name of Link" required value="<?php echo e(old('name')); ?>">
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="w-full px-3">
          <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="link">
            Very long Link
          </label>
          <input class="appearance-none block w-full bg-gray-200 text-gray-700 border <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="link" name="link" type="url" placeholder="Input Your Link" required value="<?php echo e(old('link')); ?>">
          <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="w-full px-3">
          <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="shortlink">
            Shortened Link
          </label>
          <input class="appearance-none block w-full bg-gray-200 text-gray-700 border <?php $__errorArgs = ['shortlink'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="shortlink" name="shortlink" type="text" placeholder="Short Your Link" required value="<?php echo e(old('shortlink')); ?>">
          <span id="errorshort"></span>
          <?php $__errorArgs = ['shortlink'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <button id="genrand" class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded" type="button">
        Generate Random Link
      </button>
      <button class="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded" type="submit" id="send">
        SHORT YOUR LINK
      </button>
    </form>
  </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>
  const characters ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    function generateString(length) {
    let result = '';
    const charactersLength = characters.length;
    for ( let i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}
$(document).ready(function (){
$('#genrand').click(function (e) { 
  e.preventDefault();
  $("#shortlink").val(generateString(7));
})
$('#shortlink').on('input',function(){
  var not_valid ='';
  var shortlink=$('#shortlink').val();
  var _token=$('input[name="_token"]').val();
  var filter = /^([a-zA-Z0-9_-])/
      if(!filter.test(shortlink))
      {
        $('#errorshort').html('<p class="text-red-500 text-xs italic">Shortlink tidak sesuai kriteria</p>');
        $('#shortlink').addClass('border-red-500');
        $('#send').attr('disabled', 'disabled');
      }else{
        $.ajax({
          url:"<?php echo e(route('cekLink')); ?>",
          method:"POST",
          data:{shortlink:shortlink, _token:_token},
      success:function(response)
      {
        if(response.status=='success')
        {
          $('#errorshort').html('<p class="text-green-500 text-xs italic">'+response.msg+'</p>');
          $('#shortlink').removeClass('border-red-500');
          $('#shortlink').addClass('border-green-500');
          $('#send').attr('disabled', false);
        }
        else
        {
          $('#errorshort').html('<p class="text-red-500 text-xs italic">'+response.msg.shortlink+'</p>');
          $('#shortlink').addClass('border-red-500');
          $('#send').attr('disabled', 'disabled');
        }
      }
    })
  }
})
// $('#send').click(function () { 
//   $.ajax({
//     url:"<?php echo e(route('store')); ?>",
//     method:"POST",
//     data:
//   })
//  })
});
</script>
</html><?php /**PATH D:\Coding\short-link\resources\views/home.blade.php ENDPATH**/ ?>