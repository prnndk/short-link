 ## Introduction
 Coba coba iseng untuk membuat link shortener menggunakan laravel dan juga Ajax
 -Menggunakan Bahasa PHP Dan JS
 -Frontend simple dengan tailwind css
 
 ## Fitur
 -Untuk fitur pada awal yaitu sekedar generate random short-link
 -Custom short URL
 -Jumlah Hit pada short-link yang dibuat